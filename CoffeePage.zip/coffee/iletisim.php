<!DOCTYPE html>
<head id="ctl00_Head1">
    <meta name="keywords" content="site," /><meta name="description" content="Coffee Mero" /><meta property="og:image" content="https://coffeeshop.platinum.webdeneme.com/site_document/icon_img/48XNCOW25_resim_25_5_2018_11_b.jpg" /><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="shortcut icon" href="logo.jpg" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:400,700|Titillium+Web:400,700&subset=latin,cyrillic,arabic" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" /><link rel="stylesheet" href="https://hemencdn.com/interface/platinum/css/main.css" />

    <script src="https://hemencdn.com/interface/platinum/js/modernizr.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.js"></script>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css" rel="stylesheet" /><link href="/modul_control/ilanlar/multipleSelect/css/tail.select-light.min.css" rel="stylesheet" />
    <script src="/modul_control/ilanlar/multipleSelect/js/tail.select-full.min.js"></script>
    <script src="/modul_control/ilanlar/multipleSelect/js/tail.select-tr.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

    

    <link rel="stylesheet" href="/style.css?Tema="><link href="https://fonts.googleapis.com/css?family=Poppins:400,700&subset=latin,cyrillic,arabic" rel="stylesheet" type="text/css">

<style>
body,a {font-family:Poppins!important;}
#header {padding-top:30px;}
#footer .container {padding: 50px 0 50px;}
#footer .footer-copyright {    border-top: 1px solid #4e4c47!important;}
.sayfaIcerik {padding-top:0!important;padding-bottom:0!important;}
.ui_st_326 {height:860px;padding-top:200px!important;color:#fff;font-weight:bold;}
#mainNav li a {background:none!important;font-weight:bold;}
.ana_1 {position: absolute; z-index: 999; color: #ffd266; bottom: 70px; left: 50px; font-weight: bold;}
.ana_2 {position: absolute; color: #fff; bottom: 30px; left: 50px; font-weight: bold; font-size: 20px;}
.ana_kutu {padding:40px; background:#363430;text-align:left;min-height: 428px;}
.ana_uclukutu {margin-top:-200px;}
.page-header-color h1 {line-height: 150%;background-color:transparent; padding: 50px 0px 30px 0px; font-weight:bold;}
.page-header-more-padding-xl {text-align:left!important;}
#statik_314 {width:100%!important;padding:0!important;}
#statik_314 .row-eq-height .col-md-6{padding:0;}
#detayImg {display:none;}
#iletisim #ctl00_cph1_ctl00_panel_orta .row:first-child {display:table;width:100%;margin: 0;}
#iletisim #ctl00_cph1_ctl00_panel_orta .row .col-md-6:first-child {display:table-footer-group;width:100%;float:none;}
#iletisim #ctl00_cph1_ctl00_panel_orta .row .col-md-6:nth-child(2) {display:table-header-group;width:100%;float:none;}
.page-header-custom-background { padding: 120px 0 350px;}
.IletisimBilgi h2 {display:none;}
.IletisimBilgi {margin-top: -400px;}
.iletisimkutu {width:100%;padding: 25px 40px 10px; border-radius: 5px; margin-top:50px;}
.form-control {color: #ffffff; background-color: rgba(28, 27, 25, 1); border-color: #41413f;}
.form-control:focus {color: #ffd266;border-color: #ffd266;}
.Map {margin-top:50px;}


@media (max-width: 479px){
.page-header-more-padding-xl {text-align:center!important;}
#header .header-nav-main {background:#363430!important;}
.dropdown-menu>li>a {color:#fff!important;text-align:center;}
.ui_st_326 {height:500px;padding-top:300px!important;}
.ui_st_326 .container{padding-top:150px!important;}
.ui_st_326 p span{font-size:22px!important;}
.ana_1,.ana_2 {font-size:15px;left:0; text-align:center; width:100%;}
}
</style>


<!-- #karYagdir Kar yağdırma efekti başlangıç. -->
<script type="text/javascript" src="https://hemencdn.com/widget/karEffect/karEffect.js"></script>
<!-- Kar yağdırma efekti bitiş. -->

    <script type="text/javascript">

        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', ' ']);
        _gaq.push(['_setDomainName', 'coffeeshop.platinum.webdeneme.com']);
        _gaq.push(['_trackPageview']);
        (function () {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
        })();
    </script>

    <title>
	Contact - Coffee Mero
</title></head>
<body>
    <form name="aspnetForm" method="post" action="/iletisim/m/3" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="qiOaR60LTtl/nNFaRWGbqaQX8aqgdrAovnYbmtIc2NTpue2QHGITSCojZ6GvmydIm50jJfePibkOI8RVmPZqx8jvUSpZMaNRbXCN7Iu+r0i+3CTYZ3IKdUeMUx5Q5PX8wjtp4+UeaML2ghSjjFOmp5JMTRrVgtC5/hxKZxW984e3IP7HXldETisA56PtSEkIah6jktiLNYdJr8G7SnwEz9fYaNz7abvJDl+1f4gB7AqeqUPnAtc7giuHZvDsnJB+7AZaoYkV/LS9C1zrg1PWHXKqCBeR50bBvrcVLz9HrcpZpm05Y+r8hQdfW8zOAGAQC75KwSWNA+yIzu7+vv25sWjLI9EPr6MRe6ISX6mNDe2PyCc7DAJAVJfP+kiRL0LDl+XysHWU/IE1Xt+5kjvPReAgnFGpzEj+xYQ3tShRha2/LZBKcEVR274hqWQ906tPkAnIcpH6FbPlzYmrBYC1T00NxKh6omokyOvOvrJ6XsSHXrFYnBDkGVVjmn6b+hcMTniqWuTI8XntAFPxjqiZxCSlEER/dyhv9MShtGZab+ZnFqSJ7AV3LspbTxv6wgbl666WduScBJ3fTEBndXsSLhz2etKYJvxGOhqh2tlbEd15kUL327Ks0ITUNLWICV9GHr5IxjiPr1KjiKwL0DOnYRn345mXPoJIhkEH5ziXG1AylAMo4jkWlxdGVIxHtGBpn+9WZpiEskVuBVJ3P9dReZNIJY3//+n6oAukKISc1aUb+zmroZOdbUf4S2+VaPC/tPYBydbbddFwLS7rtVf5gjJs//GU6gy6A7JFU2yRaHyG8S5vhZSxL4AsBufv/FUu0Fv1YZ3OVqi9lFHEzFtySSXVwdDiFRKBQRHSdT+nmyoyIIzgdni+nwLqSJRAjdffVg67PbvHMVYFsqb1yqnNwrow8w8Kmcgal6eASG8HPjr4xu7aQJPfWvRlN3UttKzUjXOz0aMwKaWHbfsIIoPlEoQGArPibxXHIVipKFCZC2SpY/qk2Z2QWYZdThgpxwWNmWYjA2Gv/i/Avs+w34Lwhm0n3mP9UemM7xJUabtxWW8q3R/vkCKvpZyaLFF2s7JI8GgmhgAvNhN8fYkaEvuobj2gu1Za2FAAuNhJRjB1w2+MqjZh33fx4ujz6MkOeharcq3hEh03hXsHMbWsQMwyPU+u9HVBUQbNhH3zwO1YML9PAPtQ4yc6gxCk304E45xGo0dp+8cm4k/Xla4+/i3wt8vOURVVG5Ht8fJuI9YAfTutapwVC0rdt3KXLOXxxEXzV1ZwpxwumXZCOpmEHQxtMo3qjhUQjakfA+o6DPGrY9bJfoVxPzq6VJn+FcZjB/3uYWoB9s8RkaKgmRQaD/GrykprO3OtOtvOk6EK08DxTs0ayKBE2tC0pJpoIv7m4wQAwYYqCONffFbIVYTM/Yjyn8gnF3/Fo6C2Vvixcsb7upxctwVRrBmcH+MbD0Aq8Iklt0InIdRpm8ai220t7E6YTjdzWbfudkdSXQQzd4YlOEyZs1pjLdkm2nyE0NWcnVF+I/fK8v+tH9h4zjUanjRRvRsvphnqLYsAbwt7fILvWW0oqCt9VAEvBJkUZO2QLw8LrMVLpBe+hNly56GDeVLM1/QqK1QCftP32yZqKE02XRHs6/vjMv8eDdkQpmnMIMzz4K5wxfdBS9WGLja8QBI60MxYY/f10GSFtgCE0/0HcbLKHSeEzJolrtIL2wqJ/I/fhw596XMH/XEm1N+hC+YXZqteamScNJSWDjE3VJLvoPPjMuc1Pf4x0mlKMHsOVabBER+YAarLgqSGzytytu4+PAmlC88yIXgEYkoWu+WxdQ/qIM6ybGHRyWUDxnC6qM9DWlFHUCCAbmGxOcxhfuYNBg3PBldPFDPKGAewCkyhQgXHFhuh/MEWfV5ufKKQKx47q6RI4z0pz3FuxxhGUyb64RaY0DTbpjs+hocVoNa3mvgFP+JppEfzWGDCI91L8crk5ItpdCGCLJ+02lJtZTS43OMXrbwzXNe6Rh2iQn/02FpgZc6JCuTz+Xq4VlUf/bQ0bpmfUK6iCn6VqdYE+wGmMYI3G2mBnPjG+RS9bGJvtEv7mrr4F6FqBNk7a21KrO08RHLUkADywwXJrJJ+Vl4dJOoB3a0ARnk000Xn+F/bx22UW9/o1x5QXeZ/Q2baP7Fhl1v52uIUsl6rbDqkEIdQJlQqF99cPl6Cb5WaqKr1ccrWOG71d+QThLzX/iF3BCO5BBNQdGWBxIvno2q/Rhx24JzWyb96NmjCxbm+odB+MeqH77Lh2DYab+jMm0xQhJucoLq7zL/XRSt5kgFss7xJSh3xmCk8gOVreQYWXjL+EAGt2ID1GIwBfX5jcVBynkMuHvNF3zT5L/2ZDwsGVs9+TM+81dyGyXWuGiUf4c4QppukwpVY3tUgVeO91UC6oAnFbe6BEQ==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=dW-R1S7Pn0yoIiv1xFWnvoGLX2xQWBri7bhMV4uojdA-O3-BzEdi5I4IYPKz-wnApaoEnH7QYBhOzHrUe5bWYFBf3LQ1&amp;t=635117037316159565" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=w233xViQ7YhKgv-6C2-pBq9D9t62SE4DyefOuHlhF57ZIa_JXVZxdde7AIxCjhihrj-MquTFmTuNFm48fffl3uWM1mrzeaiCz49ZkTIBeB-MbPMIrleNE-HVK1XozyOITBUMh5G7zOSpuiqTuFEYvwZOz381&amp;t=26dfbc01" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=Wa_gpXTKktBf_niJZ9tqUcrLNwLIJs194AuG5_7xT1T9XQEfLdLwyIfuLmHpBvmbg2uaWQzc-aj26GSUpBb_3atrk11eqYBiXzMSNfomvgNx6YIVjL7tZevLwSrxVngj2UzvdF2L7ffRQlRAwcRvI0_t8AJyg46_PgyPQ-bMeiIY6zqN0&amp;t=26dfbc01" type="text/javascript"></script>
<div>

	<input type="hidden" name="__SCROLLPOSITIONX" id="__SCROLLPOSITIONX" value="0" />
	<input type="hidden" name="__SCROLLPOSITIONY" id="__SCROLLPOSITIONY" value="0" />
	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="" />
</div>
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'aspnetForm', [], [], [], 90, 'ctl00');
//]]>
</script>

        <div class="body">
            <header id="header" class="headertheme_5 header-narrow header-transparent" data-plugin-options='{"stickyEnabled": false, "stickyEnableOnBoxed": false, "stickyEnableOnMobile": true, 
            "stickyStartAt": 0, "stickySetTop": "-0", "stickyChangeLogo": true}'>
  <div class="header-body">



        <div class="header-column">
            
            
</div>
<div class="headtheme_5 header-container container">
  

<div class="header-column">
  <div class="header-row">
    <div class="header-nav">
      <button class="btn header-btn-collapse-nav" type="button" data-toggle="collapse" data-target=".header-nav-main">
        <i class="fa fa-bars"></i>
      </button>
      <div class="header-nav-main header-nav-main-effect-1 header-nav-main-sub-effect-1 collapse">
      <nav>
      <nav>
          <ul class="nav nav-pills" id="mainNav">

            <li>
              <a  href ="Coffeehouse.php" id="mn_1"><i class=""> </i> HOME</a>
            </li>

            <li>
              <a  href ="hakkında.php" id="mn_306" ><i class="" > </i> ABOUT </a>
            </li>

            <li>
              <a  href ="coffees.php" id="mn_306" ><i class="" > </i> COFFEES </a>
            </li>

           

            <li>
              <a  href="iletisim.php" id="mn_3"><i class=""> </i> CONTACT</a>
            </li>

            <li>
              <a  href="create.php" id="mn_3"><i class=""> </i> LOGIN</a>
            </li>
          
        </nav>
      </div>
     
    </div>
  </div>
</div>
</div>
</div>
</div>
</header>

            <div role="main" class="main">
                
    
<!-- Üst Başlangıç -->
<div id="ctl00_cph1_UzunAlan_panel_alan_4">
	

</div>
<!-- Üst Son -->
    <section style="background-image: url(MERO.jpg);" class="page-header page-header-color page-header-custom-background iletisimHeadSection page-header-primary page-header-more-padding-xl">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        
      </div>
    </div>
  </div>
</section>

    <div class="container" id='iletisim'>

        <div class="row">
            <div class="col-md-12">
            <div id="ctl00_cph1_PanelOrta">
	

<!-- OrtaAlan2 Başlangıç -->
<div id="ctl00_cph1_ctl00_UpdatePanel1">
		
        <div id="ctl00_cph1_ctl00_panel_orta">
			
        
<div class="row">
    <div class="col-md-6" data-appear-animation="fadeInUp">
        
        
        
    <h2 class="mb-sm mt-sm">CONTACT FORM</h2>
        <div id="ctl00_cph1_ctl00_ctl01_Panel4" onkeypress="javascript:return WebForm_FireDefaultButton(event, &#39;ctl00_cph1_ctl00_ctl01_Button1&#39;)">
				
            <div class="FormAlani form-group input-group-lg">
                <label>
                Name surname</label>
                <span id="ctl00_cph1_ctl00_ctl01_RequiredFieldValidator1" style="display:inline-block;color:Red;border-style:None;display:none;">*</span>
                <input name="ctl00$cph1$ctl00$ctl01$txt_ad" type="text" id="ctl00_cph1_ctl00_ctl01_txt_ad" class="form-control" /><div class="clearfix5"></div>
                <label>
                Phone</label>
                <span id="ctl00_cph1_ctl00_ctl01_RequiredFieldValidator2" style="display:inline-block;color:Red;border-style:None;display:none;">*</span>
                <input name="ctl00$cph1$ctl00$ctl01$txt_tel" type="text" id="ctl00_cph1_ctl00_ctl01_txt_tel" class="form-control" /><div class="clearfix5"></div>
                <label>
                    GSM</label>
                <span id="ctl00_cph1_ctl00_ctl01_RequiredFieldValidator4" style="display:inline-block;color:Red;border-style:None;display:none;">*</span>
                <input name="ctl00$cph1$ctl00$ctl01$txt_cep" type="text" id="ctl00_cph1_ctl00_ctl01_txt_cep" class="form-control" /><div class="clearfix5"></div>
                <label>
                    E-Mail</label>
                <span id="ctl00_cph1_ctl00_ctl01_RegularExpressionValidator1" style="display:inline-block;color:Red;border-style:None;width:212px;display:none;">*</span>
                <span id="ctl00_cph1_ctl00_ctl01_RequiredFieldValidator3" style="display:inline-block;color:Red;border-style:None;display:none;">*</span>
                <input name="ctl00$cph1$ctl00$ctl01$txt_email" type="text" id="ctl00_cph1_ctl00_ctl01_txt_email" class="form-control" /><div class="clearfix5"></div>
                <label>
                Message</label>
                <span id="ctl00_cph1_ctl00_ctl01_RequiredFieldValidator5" style="color:Red;display:none;">*</span>
                <textarea name="ctl00$cph1$ctl00$ctl01$txt_mesaj" rows="2" cols="20" id="ctl00_cph1_ctl00_ctl01_txt_mesaj" class="form-control" style="height:100px;">
</textarea>




</textarea>
<div class="col-12">
  </div>
<button> <a class="btn btn-primary" >Submit</a></button>
            
            </div>
          
        
			</div>
    </div>
    <div class="col-md-6" data-appear-animation="fadeInUp">

        <div class="IletisimBilgi">
          <div class="row">



<div class="col-md-4">
<div class="iletisimkutu" style="background-color: rgba(255,208,95,0.8);">
<p style="color:#1C1B19;"><b>PHONE</b></p>
<p><i class="fa fa-phone" style="font-size:16px;color:#1C1B19;"></i> 
<strong><span style="font-size:20px;line-height:40px;color:#1C1B19;">+9(0212) 222 0 222</span></strong></p>
</div>
</div>

<div class="col-md-4">
<div class="iletisimkutu" style="background-color: rgba(79,76,70,0.8);">
<p style="color:#fff;"><b>FAX</b></p>
<p><i class="fa fa-fax" style="font-size:16px;color:#fff;"></i> 
<strong><span style="font-size:20px;line-height:40px;color:#fff;">+9(0212) 222 0 222</span></strong></p>
</div>
</div>


</div>
</div>
</div>
</div>



<div class="Map">
    
<script src="https://api-maps.yandex.ru/2.1/?lang=tr_TR" type="text/javascript"></script>
    <script type="text/javascript">
        ymaps.ready(init);
        var myMap, 
            myPlacemark;
 
        function init(){ 
            myMap = new ymaps.Map("harita", {
                center: [41.0082376, 28.97835889999999],
                zoom: 18
        });
 
        myPlacemark = new ymaps.Placemark([41.0082376, 28.97835889999999], { hintContent: 'Coffee Shop', balloonContent: 'Coffee Shop'
            });
             
            myMap.geoObjects.add(myPlacemark);
        }
    </script>



            <div id="harita" class="google-map" data-appear-animation="fadeInUp"></div>
</div>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
		</div>
    
	</div>
<!-- OrtaAlan2 Son -->
</div>
        </div>
        
    </div>
    </div>

    <div id="ctl00_cph1_orta">
	
<!-- OrtaAlan1 Başlangıç -->
<div id="ctl00_cph1_ctl01_UpdatePanel1">
		
        <div id="ctl00_cph1_ctl01_panel_orta">
			
        
		</div>
    
	</div>
<!-- OrtaAlan1 Son -->
</div>

            </div>

            <footer id="footer">
                <div class="container">
                    <div class="row">
                        <div id="ctl00_AltAlan_pnaltAlt">
	

<!-- ##Blok -->
<div class="col-md-4">

<div class="Blok" data-appear-animation="fadeIn" id="statik_288">
    <!-- Blok Başlık -->
    
    <div class="Area">
        <div style="background: #FFD266; border-radius: 100%; width: 40px; padding: 10px; height: 40px; text-align: center; display: inline-block;"><i class="fa fa-phone" style="font-size:16px;color:#1C1B19;"></i></div>

<p style="display: inline-block;">    
 <strong><span style="font-size:20px;line-height:40px;">+9(0212) 000 0 000</span></strong></p>

    </div>
</div>

</div>
<!-- ##Blok -->
<div class="col-md-4">

<div class="Blok" data-appear-animation="fadeIn" id="statik_254">
    <!-- Blok Başlık -->
    
    <div class="Area">
        <div style="background: #FFD266; border-radius: 100%; width: 40px; padding: 10px; height: 40px; text-align: center; display: inline-block;"><i class="fa fa-envelope" style="font-size:16px;color:#1C1B19;"></i></div>

<p style="display: inline-block;">    
 <strong><span style="font-size:20px;line-height:40px;">info@meryem.com</span></strong></p>

    </div>
</div>

</div>
<!-- ##Blok -->
<div class="col-md-4">

<div class="Blok" data-appear-animation="fadeIn" id="statik_251">
    <!-- Blok Başlık -->
    
    <div class="Area">
        
        <div class="social-theme10">
            <ul class="social-icons ">
                <li class="social-icons-facebook">
                    <a href="https://www.facebook.com/facebook" target="_blank" title="Facebook"><i class="fab fa-facebook"></i></a></li><li class="social-icons-twitter"><a href="https://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li><li class="social-icons-instagram"><a href="https://www.instagram.com/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>
            </ul>
        </div>

        
    </div>
</div>

</div>
</div>
                    </div>
                </div>
                <div class="footer-copyright" style="display: block !important; visibility: visible !important;">
                    <div class="container" style="display: block !important; visibility: visible !important;">
                        <div class="row" style="display: block !important; visibility: visible !important;">
                            <div class="col-md-6" style="display: block !important; visibility: visible !important;">
                            MSB Coffee Shop Web Site - All Rights Reserved.
                            </div>
                            <div class="col-md-6 pull-right" style="display: block !important; visibility: visible !important;">
                                <div class="pull-right" style="display: block !important; visibility: visible !important;">
                                    <div class="bilgikurumsal GenislikSub"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    
<script type="text/javascript">
//<![CDATA[
var Page_Validators =  new Array(document.getElementById("ctl00_cph1_ctl00_ctl01_RequiredFieldValidator1"), document.getElementById("ctl00_cph1_ctl00_ctl01_RequiredFieldValidator2"), document.getElementById("ctl00_cph1_ctl00_ctl01_RequiredFieldValidator4"), document.getElementById("ctl00_cph1_ctl00_ctl01_RegularExpressionValidator1"), document.getElementById("ctl00_cph1_ctl00_ctl01_RequiredFieldValidator3"), document.getElementById("ctl00_cph1_ctl00_ctl01_RequiredFieldValidator5"), document.getElementById("ctl00_cph1_ctl00_ctl01_RequiredFieldValidator6"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var ctl00_cph1_ctl00_ctl01_RequiredFieldValidator1 = document.all ? document.all["ctl00_cph1_ctl00_ctl01_RequiredFieldValidator1"] : document.getElementById("ctl00_cph1_ctl00_ctl01_RequiredFieldValidator1");
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator1.controltovalidate = "ctl00_cph1_ctl00_ctl01_txt_ad";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator1.focusOnError = "t";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator1.errormessage = "*";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator1.display = "Dynamic";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator1.validationGroup = "iletisim_validation";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator1.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator1.initialvalue = "";
var ctl00_cph1_ctl00_ctl01_RequiredFieldValidator2 = document.all ? document.all["ctl00_cph1_ctl00_ctl01_RequiredFieldValidator2"] : document.getElementById("ctl00_cph1_ctl00_ctl01_RequiredFieldValidator2");
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator2.controltovalidate = "ctl00_cph1_ctl00_ctl01_txt_tel";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator2.focusOnError = "t";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator2.errormessage = "*";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator2.display = "Dynamic";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator2.validationGroup = "iletisim_validation";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator2.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator2.initialvalue = "";
var ctl00_cph1_ctl00_ctl01_RequiredFieldValidator4 = document.all ? document.all["ctl00_cph1_ctl00_ctl01_RequiredFieldValidator4"] : document.getElementById("ctl00_cph1_ctl00_ctl01_RequiredFieldValidator4");
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator4.controltovalidate = "ctl00_cph1_ctl00_ctl01_txt_cep";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator4.focusOnError = "t";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator4.errormessage = "*";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator4.display = "Dynamic";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator4.validationGroup = "iletisim_validation";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator4.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator4.initialvalue = "";
var ctl00_cph1_ctl00_ctl01_RegularExpressionValidator1 = document.all ? document.all["ctl00_cph1_ctl00_ctl01_RegularExpressionValidator1"] : document.getElementById("ctl00_cph1_ctl00_ctl01_RegularExpressionValidator1");
ctl00_cph1_ctl00_ctl01_RegularExpressionValidator1.controltovalidate = "ctl00_cph1_ctl00_ctl01_txt_email";
ctl00_cph1_ctl00_ctl01_RegularExpressionValidator1.focusOnError = "t";
ctl00_cph1_ctl00_ctl01_RegularExpressionValidator1.errormessage = "*";
ctl00_cph1_ctl00_ctl01_RegularExpressionValidator1.display = "Dynamic";
ctl00_cph1_ctl00_ctl01_RegularExpressionValidator1.validationGroup = "iletisim_validation";
ctl00_cph1_ctl00_ctl01_RegularExpressionValidator1.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_cph1_ctl00_ctl01_RegularExpressionValidator1.validationexpression = "\\w+([-+.\']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*";
var ctl00_cph1_ctl00_ctl01_RequiredFieldValidator3 = document.all ? document.all["ctl00_cph1_ctl00_ctl01_RequiredFieldValidator3"] : document.getElementById("ctl00_cph1_ctl00_ctl01_RequiredFieldValidator3");
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator3.controltovalidate = "ctl00_cph1_ctl00_ctl01_txt_email";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator3.focusOnError = "t";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator3.errormessage = "*";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator3.display = "Dynamic";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator3.validationGroup = "iletisim_validation";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator3.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator3.initialvalue = "";
var ctl00_cph1_ctl00_ctl01_RequiredFieldValidator5 = document.all ? document.all["ctl00_cph1_ctl00_ctl01_RequiredFieldValidator5"] : document.getElementById("ctl00_cph1_ctl00_ctl01_RequiredFieldValidator5");
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator5.controltovalidate = "ctl00_cph1_ctl00_ctl01_txt_mesaj";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator5.focusOnError = "t";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator5.errormessage = "*";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator5.display = "Dynamic";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator5.validationGroup = "iletisim_validation";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator5.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator5.initialvalue = "";
var ctl00_cph1_ctl00_ctl01_RequiredFieldValidator6 = document.all ? document.all["ctl00_cph1_ctl00_ctl01_RequiredFieldValidator6"] : document.getElementById("ctl00_cph1_ctl00_ctl01_RequiredFieldValidator6");
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator6.controltovalidate = "ctl00_cph1_ctl00_ctl01_txt_newcaptcha";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator6.focusOnError = "t";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator6.errormessage = "*";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator6.display = "Dynamic";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator6.validationGroup = "iletisim_validation";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator6.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_cph1_ctl00_ctl01_RequiredFieldValidator6.initialvalue = "";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[

theForm.oldSubmit = theForm.submit;
theForm.submit = WebForm_SaveScrollPositionSubmit;

theForm.oldOnSubmit = theForm.onsubmit;
theForm.onsubmit = WebForm_SaveScrollPositionOnSubmit;

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        
document.getElementById('ctl00_cph1_ctl00_ctl01_RequiredFieldValidator1').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_cph1_ctl00_ctl01_RequiredFieldValidator1'));
}

document.getElementById('ctl00_cph1_ctl00_ctl01_RequiredFieldValidator2').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_cph1_ctl00_ctl01_RequiredFieldValidator2'));
}

document.getElementById('ctl00_cph1_ctl00_ctl01_RequiredFieldValidator4').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_cph1_ctl00_ctl01_RequiredFieldValidator4'));
}

document.getElementById('ctl00_cph1_ctl00_ctl01_RegularExpressionValidator1').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_cph1_ctl00_ctl01_RegularExpressionValidator1'));
}

document.getElementById('ctl00_cph1_ctl00_ctl01_RequiredFieldValidator3').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_cph1_ctl00_ctl01_RequiredFieldValidator3'));
}

document.getElementById('ctl00_cph1_ctl00_ctl01_RequiredFieldValidator5').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_cph1_ctl00_ctl01_RequiredFieldValidator5'));
}

document.getElementById('ctl00_cph1_ctl00_ctl01_RequiredFieldValidator6').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_cph1_ctl00_ctl01_RequiredFieldValidator6'));
}
//]]>
</script>
</form>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

    <script src="https://hemencdn.com/interface/platinum/js/main.js"></script>

    <script>
        $('a[href="' + window.location.pathname + window.location.search + '"]').parents("li,ul").addClass("active");
    </script>

    <style>
        .UzunAlanIlanAra .container {
            padding-top: 10px;
            padding-bottom: 10px;
        }
    </style>

    
    


</body>
</html>