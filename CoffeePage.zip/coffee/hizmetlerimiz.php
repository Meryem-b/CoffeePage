


<!DOCTYPE html>
<html id="ctl00_tagHtml" xmlns="https://www.w3.org/1999/xhtml" class="bk-sub bk-page bk-page-id-314">
<head id="ctl00_Head1">
    <meta name="keywords" content="HİZMETLERİMİZ,Coffee Shop,site," /><meta name="description" content=" Daima TazeÜrünlerimiz direkt fabrikadan gönderilir, tedarik süreci olmadan taze taze hazırlanır. Sitemiz üzerinden var olan bütün hizmet akışlarımızı ince" /><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <link rel="shortcut icon" href="/site_document/icon_img/48XNCOW25_resim_25_5_2018_11.jpg" />

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:400,700|Titillium+Web:400,700&subset=latin,cyrillic,arabic" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" /><link rel="stylesheet" href="https://hemencdn.com/interface/platinum/css/main.css" />

    <script src="https://hemencdn.com/interface/platinum/js/modernizr.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.js"></script>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css" rel="stylesheet" /><link href="/modul_control/ilanlar/multipleSelect/css/tail.select-light.min.css" rel="stylesheet" />
    <script src="/modul_control/ilanlar/multipleSelect/js/tail.select-full.min.js"></script>
    <script src="/modul_control/ilanlar/multipleSelect/js/tail.select-tr.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

    

    <link rel="stylesheet" href="/style.css?Tema="><link href="https://fonts.googleapis.com/css?family=Poppins:400,700&subset=latin,cyrillic,arabic" rel="stylesheet" type="text/css">

<style>
body,a {font-family:Poppins!important;}
#header {padding-top:30px;}
#footer .container {padding: 50px 0 50px;}
#footer .footer-copyright {    border-top: 1px solid #4e4c47!important;}
.sayfaIcerik {padding-top:0!important;padding-bottom:0!important;}
.ui_st_326 {height:860px;padding-top:200px!important;color:#fff;font-weight:bold;}
#mainNav li a {background:none!important;font-weight:bold;}
.ana_1 {position: absolute; z-index: 999; color: #ffd266; bottom: 70px; left: 50px; font-weight: bold;}
.ana_2 {position: absolute; color: #fff; bottom: 30px; left: 50px; font-weight: bold; font-size: 20px;}
.ana_kutu {padding:40px; background:#363430;text-align:left;min-height: 428px;}
.ana_uclukutu {margin-top:-200px;}
.page-header-color h1 {line-height: 150%;background-color:transparent; padding: 50px 0px 30px 0px; font-weight:bold;}
.page-header-more-padding-xl {text-align:left!important;}
#statik_314 {width:100%!important;padding:0!important;}
#statik_314 .row-eq-height .col-md-6{padding:0;}
#detayImg {display:none;}
#iletisim #ctl00_cph1_ctl00_panel_orta .row:first-child {display:table;width:100%;margin: 0;}
#iletisim #ctl00_cph1_ctl00_panel_orta .row .col-md-6:first-child {display:table-footer-group;width:100%;float:none;}
#iletisim #ctl00_cph1_ctl00_panel_orta .row .col-md-6:nth-child(2) {display:table-header-group;width:100%;float:none;}
.page-header-custom-background { padding: 120px 0 350px;}
.IletisimBilgi h2 {display:none;}
.IletisimBilgi {margin-top: -400px;}
.iletisimkutu {width:100%;padding: 25px 40px 10px; border-radius: 5px; margin-top:50px;}
.form-control {color: #ffffff; background-color: rgba(28, 27, 25, 1); border-color: #41413f;}
.form-control:focus {color: #ffd266;border-color: #ffd266;}
.Map {margin-top:50px;}


@media (max-width: 479px){
.page-header-more-padding-xl {text-align:center!important;}
#header .header-nav-main {background:#363430!important;}
.dropdown-menu>li>a {color:#fff!important;text-align:center;}
.ui_st_326 {height:500px;padding-top:300px!important;}
.ui_st_326 .container{padding-top:150px!important;}
.ui_st_326 p span{font-size:22px!important;}
.ana_1,.ana_2 {font-size:15px;left:0; text-align:center; width:100%;}
}
</style>


<!-- #karYagdir Kar yağdırma efekti başlangıç. -->
<script type="text/javascript" src="https://hemencdn.com/widget/karEffect/karEffect.js"></script>
<!-- Kar yağdırma efekti bitiş. -->

    <script type="text/javascript">

        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', ' ']);
        _gaq.push(['_setDomainName', 'coffeeshop.platinum.webdeneme.com']);
        _gaq.push(['_trackPageview']);
        (function () {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
        })();
    </script>

    <title>
	HİZMETLERİMİZ - Coffee Shop
</title></head>
<body>
    <form name="aspnetForm" method="post" action="/hizmetlerimiz" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="LkHoCqWOnNBbopz765/YKOmLif2K4GWYAe538yIbNDRUuvphfctxSHOgD6K+14WAl1Eq99rJwxtePpU9ECnx3hk/0651pjU31wsj9SIOT9am5jrLn3IH9EDgEV4W9aEtSKe0IbvfLhFJen7nVOXf5OUyxlYYRSWWf0DD5Cpvuk2DrLT0EGp1awVPCSCtpEe9SWxNrTT/xLK4n5bEtXJflUZ8FivC596GUZyFd8QMkONqseBRRGdmIxt/ksyMKa2G+4R5BTuhA8bpLJRky+qZ4M/P6MMp9MPknjppvAVgnlo79lsyVhaOzsRVSHOMHiOoaroggca2NvYZryCySyPADNOQ1iHPoQuhbHBLSRXfB9WUOZj1xI66rN+wEwVs/IZDrmoAHun3KgEY9vG/87BBbCc5o22klUxviIUclRfqAxVHgxWtqlg3qwpdDZzuKuVnhGU8YRtRG1sBr2+OZYhDQ7rNaA7sRxom8Haa2GlYelSaoh1uL7PTEekom0VO5UOgPVrqXRuSG/Sq8vIiNoB8ptPRSaF/6ZD4LBZbMFUMhKlmREG8p3JbU6vJRA4fQO0SBpMirvaf4q6KItFI5L4Qebs2ohZWIK8hLCrNEGpEkXq3erA6Z26Y9+MAaQ0RBfQ+wM46RQhuh8YFTSxwsiRb4NfrA6D46jfbJGq+X7f+4p7yVOkBkvWpt/dMibHQSIrtXQQxcj9jVCJt9AOTTWKnEc489oVpnrXD6w66Ln5AFmw+5pGN+fLhZKWkeaxusD/n1et8QvueejckxyBaTG01myY1633Aqh51pZx59SoKF6wPF93p+BsEVi3wFmnLqYfsIk4x0DqfAAKoAnv/E14XwLby2Ssv+sdNTtCIuzRi6uVomOBH4ckOeizyUkNTaN0s+/1birm6n9MChmY6qe/aMaxbCvkhyckwsGs36naEBFHyN1NuSa+ica3R3yuMK5KOb0V1gFjyZpXkvA+l/SYZb+/N4lwnGV11d/alJRO8v+4i0IFkuY+P2VNwb+ftGOeqYLDvjLdu/nNBBWIfV4N1j0HzFAtIury1HVjaLR+xBUSVdij/c4yN3G/7uT4nhsuMN1dxDDSxjugn7JQLWIyhBrSrWxcp5ksHKHL9wtVFtx1uQJaILrvYGvtYcO8B4wc2A6kvNQnAuQ+4uNcL3/fIsziViAztXoexYgI31zh1n1iWNge7dVsU3UJEwm/FBKCZKVRn6Kpu+wMmt1gbwdmPeIp2NQThxWAylBbE9iJOo2f79FZ9PYb9Gjna1+QDPadYti9oqxinTUDczrFAU0d/8KvKCd/I3azANu7jc48ay4QqBxH8lRjuaHDFBiW20wtJd50UQKpb5L9HMW4KUP44OAgEQmq+4cFjc9+MLCSfP9wMs+ej0NIuk9Cls4J27dFRlYTD1rlz3bd0Qrd30UYo3aXgz06y7MnBqJ0C3fAJacLiFOk5BiKwW7yYqIDTErOTFaxZtXI2/66mEvhVN5FeQxZkjVcrUNybM4s0wCcIK7CwjFYW+Gl7FshvwXQqPF+hoUIY2zhY+h+gpB3ntYqvC5u2lqfw+/6lc8Kn1hFKwIcghRSAwx8/t1bo4zRFOhlweZfOOlHkvXEbWjjObDktdmfcYOoyZicXdo8kP7UYR6LTKzW+4kag1rwxTQ0Zt5LojyfXQ/D6XD+mwPH1YETGs3gU69CT+JA2w6b9j3fKPJLwJzX396LYWeQJWZ9C0oiMaORJD3Ypiicvi2BNOkfn9dGdsjUC36SxpyQQ82KRPZJwhLds7I2RW0LKMW8/kifNChlofXtJ0q92e/20uV0ma57LjbbADnzEubNeOdX6Nzf3GklFHMQ1X3xgTmFsMLqeKNm6l0Ue7yk0jLyh4UacNcREwkWj+T1eay/wcKtsI//B0WNoViV771fyZyE+nzIMZumA0Nxkke6YezzsCkJ/xi5CvwodslEDrJZ8hnodZHf4jlnB++wF8jcfkw9n6ibze5PVqPwD3V0eP4Mtc9LXFIgwVlAfFDnidNd3jxxeM/jsYBG0vQyPHEF6djElC7QybJrP6KnxtaDAjXDaKsnBPedeTXs2D1yScSHPFd7b0g6Aem6RIILTJ3lZrjmDFt42EBlOg4P8GP6gW9GwMJWgH0eSRUkDbCSBLVxpVd1wQbFmFgacEPfzbk+OhH1b+NeM35M45DIfBoArMCijatrSwYWkOSuaxqh/gF8pGso60KasGytufk4wUd9XKR0hlfk4tTeoQhy45ZNQjOwb3IN/n+UJOHoloPNQ6KPeZMUQxKXqg/JugME0ke/oveRR0+pD+ap6+5CAcClwRFA3uxUGSCqSzud2hFrztBR3bAtWAM36HfGGT9LggK/NnQ0MG/sX/NIPiH1fTyq4wj/9FCwy8mda97TWHbpu/ZCnVR3gvie2OqYSv2m3TowSQuqfTeYPa8PPdXpnPy9Rki8K28WVhnTEXP4=" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=dW-R1S7Pn0yoIiv1xFWnvoGLX2xQWBri7bhMV4uojdA-O3-BzEdi5I4IYPKz-wnApaoEnH7QYBhOzHrUe5bWYFBf3LQ1&amp;t=635117037316159565" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=w233xViQ7YhKgv-6C2-pBq9D9t62SE4DyefOuHlhF57ZIa_JXVZxdde7AIxCjhihrj-MquTFmTuNFm48fffl3uWM1mrzeaiCz49ZkTIBeB-MbPMIrleNE-HVK1XozyOITBUMh5G7zOSpuiqTuFEYvwZOz381&amp;t=26dfbc01" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=Wa_gpXTKktBf_niJZ9tqUcrLNwLIJs194AuG5_7xT1T9XQEfLdLwyIfuLmHpBvmbg2uaWQzc-aj26GSUpBb_3atrk11eqYBiXzMSNfomvgNx6YIVjL7tZevLwSrxVngj2UzvdF2L7ffRQlRAwcRvI0_t8AJyg46_PgyPQ-bMeiIY6zqN0&amp;t=26dfbc01" type="text/javascript"></script>
<div>

	<input type="hidden" name="__SCROLLPOSITIONX" id="__SCROLLPOSITIONX" value="0" />
	<input type="hidden" name="__SCROLLPOSITIONY" id="__SCROLLPOSITIONY" value="0" />
	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="" />
</div>
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'aspnetForm', [], [], [], 90, 'ctl00');
//]]>
</script>

        <div class="body">
            <header id="header" class="headertheme_5 header-narrow header-transparent" data-plugin-options='{"stickyEnabled": false, "stickyEnableOnBoxed": false, "stickyEnableOnMobile": true, "stickyStartAt": 0, "stickySetTop": "-0", "stickyChangeLogo": true}'>
  <div class="header-body">



        <div class="header-column">
            
            
</div>
<div class="headtheme_5 header-container container">
  <div class="header-row">
    <div class="header-column">
      <div class="header-logo">
        <p><a href="/"><img alt="" src="/site_document/files/resim/UFQ2YKB1Hcoffee.png" style="width: 150px; height: 133px;" /></a></p>

      </div>
    </div>

<div class="header-column">
  <div class="header-row">
    <div class="header-nav">
      <button class="btn header-btn-collapse-nav" type="button" data-toggle="collapse" data-target=".header-nav-main">
        <i class="fa fa-bars"></i>
      </button>
      <div class="header-nav-main header-nav-main-effect-1 header-nav-main-sub-effect-1 collapse">
      <nav>
          <ul class="nav nav-pills" id="mainNav">

            <li>
              <a  href ="kahvesitesi.php" id="mn_1"><i class=""> </i> ANASAYFA</a>
            </li>

            <li>
              <a  href ="hakkında.php" id="mn_306"><i class="" > </i> HAKKIMIZDA</a>
            </li>

            <li>
              <a  href="hizmetlerimiz.php" id="mn_314"><i class=""> </i> H&#304;ZMETLER&#304;M&#304;Z</a>
            </li>

            <li>
              <a  href="iletisim.php" id="mn_3"><i class=""> </i> &#304;LET&#304;&#350;&#304;M</a>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
</div>
</div>
</div>
</div>
</header>

            <div role="main" class="main">
                
    
<!-- Üst Başlangıç -->
<div id="ctl00_cph1_UzunAlan_panel_alan_4">
	

</div>
<!-- Üst Son -->
    <section style="background-color:#363430" class="page-header page-header-color SayfaHeadSec SayfaHeadSec314 page-header-primary page-header-more-padding-xl">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 style="font-size:60px;color:#FFFFFF">
          H&#304;ZMETLER&#304;M&#304;Z
        </h1>
      </div>
    </div>
  </div>
</section>

    <div class="container sayfaIcerik" id="statik_314">

        <div class="row">
            <div class="col-md-12">
            <div id="ctl00_cph1_PanelOrta">
	

<!-- OrtaAlan2 Başlangıç -->
<div id="ctl00_cph1_ctl00_UpdatePanel1">
		
        <div id="ctl00_cph1_ctl00_panel_orta">
			
        
<!-- ##Blok -->

<div data-appear-animation="fadeInUp">
    <div class="row row-eq-height">
<div class="col-md-6 col-xs-12"><img alt="" class="img-responsive" src="/site_document/files/resim/5NWG3R71Qhizmet1.jpg" /></div>

<div class="col-md-6 col-xs-12" style="background:#fff;padding: 40px;">
<p><img alt="" src="/site_document/files/resim/5IB014734home1.png" style="width: 50px; height: 50px;" /></p>

<p> </p>

<p><span style="font-size:40px;"><span style="color:#000000;"><strong>Daima Taze</strong></span></span></p>

<p><span style="color:#6c6c6c;">Ürünlerimiz direkt fabrikadan gönderilir, tedarik süreci olmadan taze taze hazırlanır. </span></p>

<p><span style="color:#6c6c6c;">Sitemiz üzerinden var olan bütün hizmet akışlarımızı inceleyebilir, kendinize hitap eden modeli seçerek de bizler ile iletişime geçebilirsiniz. </span></p>

<p><span style="color:#6c6c6c;">Dilediğiniz hizmeti en kısa zamanda önünüze sunarak sizlere harika bir kahve sunumunu aktarabiliriz.</span></p>
</div>
</div>

<div class="row row-eq-height">
<div class="col-md-6 col-xs-12"><img alt="" class="img-responsive" src="/site_document/files/resim/C9OFM8KH0hizmet2.jpg" /></div>

<div class="col-md-6 col-xs-12" style="background:#fff;padding: 40px;">
<p><img alt="" src="/site_document/files/resim/ABL9NODPChome2.png" style="width: 50px; height: 50px;" /></p>

<p> </p>

<p><span style="font-size:40px;"><span style="color:#000000;"><strong>Çekirdek
Puan</strong></span></span></p>

<p><span style="color:#6c6c6c;">Her siparişinizde %5 puan kazanın, mağazalarımızda dilediğiniz gibi harcayın. </span></p>

<p><span style="color:#6c6c6c;">Türkiye'de 100'den fazla noktada.</span></p>
</div>
</div>

</div>
<div id="ctl00_cph1_ctl00_ctl01_panel_alan_4">
				

			</div>
		</div>
    
	</div>
<!-- OrtaAlan2 Son -->
</div>
        </div>
        
    </div>
    </div>

    <div id="ctl00_cph1_orta">
	
<!-- OrtaAlan1 Başlangıç -->
<div id="ctl00_cph1_ctl01_UpdatePanel1">
		
        <div id="ctl00_cph1_ctl01_panel_orta">
			
        
		</div>
    
	</div>
<!-- OrtaAlan1 Son -->
</div>

            </div>

            <footer id="footer">
                <div class="container">
                    <div class="row">
                        <div id="ctl00_AltAlan_pnaltAlt">
	

<!-- ##Blok -->
<div class="col-md-4">

<div class="Blok" data-appear-animation="fadeIn" id="statik_288">
    <!-- Blok Başlık -->
    
    <div class="Area">
        <div style="background: #FFD266; border-radius: 100%; width: 40px; padding: 10px; height: 40px; text-align: center; display: inline-block;"><i class="fa fa-phone" style="font-size:16px;color:#1C1B19;"></i></div>

<p style="display: inline-block;">     <strong><span style="font-size:20px;line-height:40px;">+9(0212) 444 0 444</span></strong></p>

    </div>
</div>

</div>
<!-- ##Blok -->
<div class="col-md-4">

<div class="Blok" data-appear-animation="fadeIn" id="statik_254">
    <!-- Blok Başlık -->
    
    <div class="Area">
        <div style="background: #FFD266; border-radius: 100%; width: 40px; padding: 10px; height: 40px; text-align: center; display: inline-block;"><i class="fa fa-envelope" style="font-size:16px;color:#1C1B19;"></i></div>

<p style="display: inline-block;">     <strong><span style="font-size:20px;line-height:40px;">info@webdeneme.com</span></strong></p>

    </div>
</div>

</div>
<!-- ##Blok -->
<div class="col-md-4">

<div class="Blok" data-appear-animation="fadeIn" id="statik_251">
    <!-- Blok Başlık -->
    
    <div class="Area">
        
        <div class="social-theme10">
            <ul class="social-icons ">
                <li class="social-icons-facebook"><a href="https://www.facebook.com/facebook" target="_blank" title="Facebook"><i class="fab fa-facebook"></i></a></li><li class="social-icons-twitter"><a href="https://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li><li class="social-icons-instagram"><a href="https://www.instagram.com/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>
            </ul>
        </div>

        
    </div>
</div>

</div>
</div>
                    </div>
                </div>
                <div class="footer-copyright" style="display: block !important; visibility: visible !important;">
                    <div class="container" style="display: block !important; visibility: visible !important;">
                        <div class="row" style="display: block !important; visibility: visible !important;">
                            <div class="col-md-6" style="display: block !important; visibility: visible !important;">
                                Copyright (c) 2020 Coffee Shop Web Sitesi - Tüm Hakları Saklıdır.
                            </div>
                            <div class="col-md-6 pull-right" style="display: block !important; visibility: visible !important;">
                                <div class="pull-right" style="display: block !important; visibility: visible !important;">
                                    <div class="bilgikurumsal GenislikSub"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    

<script type="text/javascript">
//<![CDATA[

theForm.oldSubmit = theForm.submit;
theForm.submit = WebForm_SaveScrollPositionSubmit;

theForm.oldOnSubmit = theForm.onsubmit;
theForm.onsubmit = WebForm_SaveScrollPositionOnSubmit;

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        //]]>
</script>
</form>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

    <script src="https://hemencdn.com/interface/platinum/js/main.js"></script>

    <script>
        $('a[href="' + window.location.pathname + window.location.search + '"]').parents("li,ul").addClass("active");
    </script>

    <style>
        .UzunAlanIlanAra .container {
            padding-top: 10px;
            padding-bottom: 10px;
        }
    </style>

    
    


</body>
</html>