<!DOCTYPE html>
<head id="ctl00_Head1">
    <meta name="keywords" content="site," /><meta name="description" content="Coffee Mero" /><meta property="og:image" src="in.jpg" /><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="shortcut icon" href="logo.jpg" />
  <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <!-- Web Fonts  -->
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:400,700|Titillium+Web:400,700&subset=latin,cyrillic,arabic" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" /><link rel="stylesheet" href="https://hemencdn.com/interface/platinum/css/main.css" />
    <script src="https://hemencdn.com/interface/platinum/js/modernizr.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css" rel="stylesheet" /><link href="/modul_control/ilanlar/multipleSelect/css/tail.select-light.min.css" rel="stylesheet" />
    <script src="/modul_control/ilanlar/multipleSelect/js/tail.select-full.min.js"></script>
    <script src="/modul_control/ilanlar/multipleSelect/js/tail.select-tr.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    <link rel="stylesheet" href="/style.css?Tema="><link href="https://fonts.googleapis.com/css?family=Poppins:400,700&subset=latin,cyrillic,arabic" rel="stylesheet" type="text/css">

<style>
body,a {font-family:Poppins!important; background-image:url("whiye.jpg");background-repeat:no-repeat; background-size: cover;}
#header {padding-top:30px;}
#footer .container {padding: 50px 0 50px;}
#footer .footer-copyright {    border-top: 1px solid #4e4c47!important;}
.sayfaIcerik {padding-top:0!important;padding-bottom:0!important;}
.ui_st_326 {height:860px;padding-top:200px!important;color:#fff;font-weight:bold;}
#mainNav li a {background:none!important;font-weight:bold;}
.ana_1 {position: absolute; z-index: 999; color: #ffd266; bottom: 70px; left: 50px; font-weight: bold;}
.ana_2 {position: absolute; color: #fff; bottom: 30px; left: 50px; font-weight: bold; font-size: 20px;}
.ana_kutu {padding:40px; background:#363430;text-align:left;min-height: 428px;}
.ana_uclukutu {margin-top:-200px;}
.page-header-color h1 {line-height: 150%;background-color:transparent; padding: 50px 0px 30px 0px; font-weight:bold;}
.page-header-more-padding-xl {text-align:left!important;}
#statik_314 {width:100%!important;padding:0!important;}
#statik_314 .row-eq-height .col-md-6{padding:0;}
#detayImg {display:none;}
#iletisim #ctl00_cph1_ctl00_panel_orta .row:first-child {display:table;width:100%;margin: 0;}
#iletisim #ctl00_cph1_ctl00_panel_orta .row .col-md-6:first-child {display:table-footer-group;width:100%;float:none;}
#iletisim #ctl00_cph1_ctl00_panel_orta .row .col-md-6:nth-child(2) {display:table-header-group;width:100%;float:none;}
.page-header-custom-background { padding: 120px 0 350px;}
.IletisimBilgi h2 {display:none;}
.IletisimBilgi {margin-top: -400px;}
.iletisimkutu {width:100%;padding: 25px 40px 10px; border-radius: 5px; margin-top:50px;}
.form-control {color: #ffffff; background-color: rgba(28, 27, 25, 1); border-color: #41413f;}
.form-control:focus {color: #ffd266;border-color: #ffd266;}
.Map {margin-top:50px;}


@media (max-width: 479px){
.page-header-more-padding-xl {text-align:center!important;}
#header .header-nav-main {background:#363430!important;}
.dropdown-menu>li>a {color:#fff!important;text-align:center;}
.ui_st_326 {height:500px;padding-top:300px!important;}
.ui_st_326 .container{padding-top:150px!important;}
.ui_st_326 p span{font-size:22px!important;}
.ana_1,.ana_2 {font-size:15px;left:0; text-align:center; width:100%;}
}
</style>
<!-- #rYagdir Kar yağdırma efekti başlangıç. -->
<script type="text/javascript" src="https://hemencdn.com/widget/karEffect/karEffect.js"></script>
<!-- Kar yağdırma efekti bitiş. -->

    <script type="text/javascript">

        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', ' ']);
        _gaq.push(['_setDomainName', 'coffeeshop.platinum.webdeneme.com']);
        _gaq.push(['_trackPageview']);
        (function () {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
        })();
    </script>

    <title>
  COFFEE MERO 
</title></head>
<body  >
    <form name="aspnetForm" method="post" action="" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="H4BUZ7HrNrXkalsRoZnXJIVW0V1/fNzAVNTTPlgprypbEnYImnJ8adefc8WiIbnfWUHJXNnHczP89DhW4hWVRDJw1EneYEQ329gncH1ycWRWtfCm3W+J/bwVkxs7Rw+xkHfPht28yAcIG9WuswvRoNlYC3V+m3k3+BwQ4IFu/2tPxg7gsMUi/b0MdDXf/arG3HwizM2nMRIMyR4EGBGG0fWXRDh6t5SAPMMIZQOwk7k8Ro3dTUzpiDWFv1fQHeTDeWQQJA3+kcUPLfvdjPUoOdwofkKvCpq1Z3u+nv3LM34DL3ZIhSC+Se7kUR3d3mutnKDUic8ALRAdB5pOF8nWfF/7DHA9Z8bk4e87+GIgrbLtVQ9/9XWWPSACd5s1b7PlIZuVxOwwmsqx43HPZgYokDaYTJJkfZXkNKwSu/Qo/S6RTPHLBpyig9djtls4TViQzP1wny0AaeklW4hHQ6k6Fkkm3qmZBmR9Q6dvQoZU/tNDoygEqURSrXPyA47kEy3mT4Mlvs3ZQpsYXTRGniginpGShEmdEC7l3yHnrPWNG98ydofMee0noWskjr4w/HzoTopDayN83iE7ZNeEUeDUP04PZMpjZo28x3O40yHmKXbjl3k+iYJvwHwEOIyedfvfA1kj9tVDe5K6Lv08ndt+mCk/oyBNctosQgemLTsKyJL0TPOuQK8JINlDh3ju0NPKEKb9qaxkIdl1eIjzVAzw9lmTNewieX737c79Abof1P9Got1ZRDeNxsh+iC8dMmTJ4S2TzxMkyyGs9xIqClCHuMQAY25nrO3Pgo74cWqKt3heSqw5OOHnlRJrhenXNpQo2xwudHGxyi0ROgZkc8h+3vDRPtT2YwLaizY3mMH/ZACp020KtSf92NLvM/lYyeU/6CA3GvRpxwLisRye5efOgch8VjDr5HH2tR85W2qvVjU7BbcX/1x/G7IHy3QlE2DJiRbjlk+brQryCaCqlDz68lPGR73X1/BNKh0VjSP9is8LM9+7tKmwk5fDiI9ric3EwcMtxqBKp9YyLV71/oxfz1rhyqq0uJbTI9mHiJuTgWD+RVx20H5RrWPipYoqrPdy7E6pLOjtHRExqaWS8ODDX1BLGZdJJ4ZJxr+DdbJpPzdT0oTNBDAduK5CzDlC/4P9pGmJZusjIQJDqbzaq3K1JdAa7Z7nnKKcyORIn7L2eKG4x6VTwxFjOY65rnqPpEWSrftzyByRNe4Rciv0DLTc9WCrPSHd79/FkrZWuKITdFHUEsklYYBnjXMLUITtyD3v4bqB7PriRWBzufk/iqc/mz+xefJPRBPv4kr+vazESkAPb3SlV34gEmchX+9Z6YQ/r1AY3Qrpqn2ZVNYW4jQ8uFhC9HUB2QsY149trQAyuTKLO9wQBOASIH5n4Fs0JouugXVfqoJdU1RvN+iC4x/pI6d2K55xC5Sa7oe5uNsuA57e2BUVgg+/IzKQs1eT4RCP/OEHCDS2tltoJhcHfVwM+XNfI2hoDsh4YiIDg/vpjnD8BNzVhZScYhOQdW4n5plZ7gb47cTMYFKoqybvVaAFyh6jKtw7gpmPjjFBe5iQrTLBaCHIMGfr9CV02hyvZ7p25RNHX8kKSBALmk7TUgwqQjSfoPdfovLVs/QbkBbasbDQgdcvAduYYyyGpXhwbBKtOC1mTTa0G6b8vfEVEo5Ltz00R8yyePAwJXyuDpAnBXv2p2TUTlkpihUBYB5kjEvcHC+jfETPxGscP5hdjm1AKeyz3zo8GENphhh6aiHWG3Pr3AXQqbirJM4mpBAiIX/FPS+BJiR+o60XckfXCvFisG25kTVyLaQ5TeF9Zo1lANP4rAy7NQhLlvaa7nMRIeBEa/+Z8157Y4vs5+tDl1sGUtweizBpsOq8sVqYUI3Zl8A+vdjwaitzJklCEXW0d2d1C+h729KkFUKj9OjMCgYiUDkUBAWIaqXEZkwJdprbjW03c40nk70QL4/jWchpmMagLnq8JXXL8g5N59uh1blVk8OeMF4wIWYmbDMm8bX3EGZ/efM1MOW3reJsfOC64ODfZcwV/2X8Lvm81nZEF2lsa5WghmISHjO1eiEX34tRyrNUV3FqKBc90KKTDyTsBLWBh4LUjStMPxCSuA2J4QtbfC2H/pcKTDcax+Anp9PBTOeFm3eaQHV3jyzGv3gBaTO6BxMUuMjIUSdGK1XASafKafDkMX0SBauWlA+jxP2W0Ht/BVcAdznz6gIs7Q4crTbvDKGYhrwaJlhWZYNOdvLnHhuzu4fmZpwxkUl7FgHg8vArM4qCGf63lv3SWqyJpFbk70trRu8AyaRtzyJzXyXUliul3HaILeM4+F580m1qMzNwQWj8gppOYJlzTcc5GwQYp/DnMoeCuytVAnbGp497N4W3r3I=" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=dW-R1S7Pn0yoIiv1xFWnvoGLX2xQWBri7bhMV4uojdA-O3-BzEdi5I4IYPKz-wnApaoEnH7QYBhOzHrUe5bWYFBf3LQ1&amp;t=635117037316159565" type="text/javascript"></script>

<script src="/ScriptResource.axd?d=w233xViQ7YhKgv-6C2-pBq9D9t62SE4DyefOuHlhF57ZIa_JXVZxdde7AIxCjhihrj-MquTFmTuNFm48fffl3uWM1mrzeaiCz49ZkTIBeB-MbPMIrleNE-HVK1XozyOITBUMh5G7zOSpuiqTuFEYvwZOz381&amp;t=26dfbc01" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=Wa_gpXTKktBf_niJZ9tqUcrLNwLIJs194AuG5_7xT1T9XQEfLdLwyIfuLmHpBvmbg2uaWQzc-aj26GSUpBb_3atrk11eqYBiXzMSNfomvgNx6YIVjL7tZevLwSrxVngj2UzvdF2L7ffRQlRAwcRvI0_t8AJyg46_PgyPQ-bMeiIY6zqN0&amp;t=26dfbc01" type="text/javascript"></script>
<div>

	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="" />
</div>
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'aspnetForm', ['tctl00$cph1$OrtaAlan$UpdatePanel1',''], [], [], 90, 'ctl00');
//]]>
</script>

<div class="body">
            <header id="header" class="headertheme_5 header-narrow header-transparent" data-plugin-options='{"stickyEnabled": false, "stickyEnableOnBoxed": false, "stickyEnableOnMobile": true, 
            "stickyStartAt": 0, "stickySetTop": "-0", "stickyChangeLogo": true}'>
  <div class="header-body">



        <div class="header-column">
            
            
</div>
<div class="headtheme_5 header-container container">
  

<div class="header-column">
  <div class="header-row">
    <div class="header-nav">
      <button class="btn header-btn-collapse-nav" type="button" data-toggle="collapse" data-target=".header-nav-main">
        <i class="fa fa-bars"></i>
      </button>
      <div class="header-nav-main header-nav-main-effect-1 header-nav-main-sub-effect-1 collapse">
      <nav>
      <nav>
          <ul class="nav nav-pills" id="mainNav">

            <li>
              <a  href ="Coffeehouse.php" id="mn_1"><i class=""> </i> HOME</a>
            </li>

            <li>
              <a  href ="hakkında.php" id="mn_306" ><i class="" > </i> ABOUT </a>
            </li>

            <li>
              <a  href ="coffees.php" id="mn_306" ><i class="" > </i> COFFEES </a>
            </li>

            

            <li>
              <a  href="iletisim.php" id="mn_3"><i class=""> </i> CONTACT</a>
            </li>

            <li>
              <a  href="create.php" id="mn_3"><i class=""> </i> LOGIN</a>
            </li>
            
        </nav>
      </div>
     
    </div>
  </div>
</div>
</div>
</div>
</div>
</header>

            <div role="main" class="main">

                         
            
<!-- Üst Başlangıç -->
<div id="ctl00_cph1_UzunAlan_panel_alan_4">
	
</div>



<section  style="background-image:url(o.jpg); background-repeat:no-repeat; background-size: cover;" class="page-header page-header-color SayfaHeadSec SayfaHeadSec306 page-header-primary page-header-more-padding-xl">
    
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h1 style="font-size:60px;color:#FFFFFF" >
            ABOUT US
          </h1>
        </div>
      </div>
    </div>
  </section>

  <div></div>
  <div></div>
  <div></div>

<!-- OrtaAlan2 Başlangıç -->
<div id="ctl00_cph1_ctl00_UpdatePanel1">
		
        <div id="ctl00_cph1_ctl00_panel_orta">
			
      
     
       
        
<!-- ##Blok -->
<p> </p>
<div data-appear-animation="fadeInUp">
    <div class="row row-eq-height">
<div class="col-md-6 col-xs-12"><img src="shop.jpg" width="655px" height="600px"></div>

<div class="col-md-6 col-xs-12" style="background:#fff;padding: 30px;" >
<p><span style="font-size:22px;"><span style="color:#000000;"><strong>Our Coffee Mission</strong></span></span></p>

<p style="color:#000000;">Our Mission: to be a brand that inspires and enriches the human spirit. We serve you every time, thinking that it can be your first meeting with us and your first coffee.
Here are our principles we strive to adhere to in order to always deliver the best coffee Experience:

our coffee
It has always been of good quality and will always remain so. We work hard to source the highest quality coffee beans, roast them with the utmost care, and improve the quality of life of the communities that grow these coffee beans. We attach great importance to this issue and we are always improving ourselves to do better.

Our Business Partners
We call our employees our business partners, because for us it's not just a job, it's our passion. Together we embrace diversity to create a space where we can all be ourselves. We always approach each other with respect and understanding.

Our guests
No matter how busy we are, we connect with our guests, even for a few seconds, laugh with them and try to raise their morale. This of course starts with the promise to make the perfect drink, but our job goes far beyond that.
</p>

<p> </p>
<p><span style="font-size:22px;"><span style="color:#000000;"><strong>Neighbors</strong></span></span></p>

<p><span style="color:#000000;">Each of our stores is a part of society, we take our responsibilities seriously to be a good neighbor. We would like to be present with the demands of our guests wherever we serve. We strive to bring our employees, guests and communities together to do good things together. We know that we have a great responsibility and potential to make a positive contribution to the societies we live in.Our Shareholders
As we evolve in each of these areas, we enjoy successes that satisfy our shareholders. We are entirely responsible for perfecting each of these elements so that coffee and every participating shareholder can survive and thrive.</span></p>

</div>
</div>

</div>
<div id="ctl00_cph1_ctl00_ctl01_panel_alan_4">
				

			</div>
		</div>
    
	</div>


    <br>
        <br>

   

<!-- OrtaAlan2 Son -->
</div>
        </div>
        
    </div>
    </div>

    <div id="ctl00_cph1_orta">
	
<!-- OrtaAlan1 Başlangıç -->
<div id="ctl00_cph1_ctl01_UpdatePanel1">
		
        <div id="ctl00_cph1_ctl01_panel_orta">
			
        
		</div>
    
	</div>
       
<!-- Üst Başlangıç -->
<div id="ctl00_cph1_UzunAlan_panel_alan_4">
	

    </div>
    <!-- Üst Son -->
        
    <!-- ##Blok -->
    <section class="statik ui_st_330 parallax section section-parallax section-center mb-none" data-stellar-background-ratio="0.5" style="background-color:#141414;">
      <div class="container">
        <div class="row">
          <div class="col-md-12"  >
            <div class="row">
              <div class="col-md-12"  >
              <script src="https://hemencdn.com/widget/instagram/index.js"></script> <!-- instgramdan çek -->
    <div class="container">
    <div class="instagram_feed" id="instagram-portfolio"> </div>
    </div>
    <script>
     (function($){
            $(window).on('load', function(){
                $.instagramFeed({
                    'username': 'coffeeshopofficial',
                    'container': "#instagram-portfolio",
                    'display_profile': true,
                    'display_biography': true,
                    'display_gallery': true,
                    'get_raw_json': false,
                    'callback': null,
                    'styling': true,
                    'items': 28,
                    'items_per_row': 4,
                    'margin': 1
                });
            });
        })(jQuery);
      </script>
              </div>
            </div>
        </div>
        </div>
      </div>
    </section>
    
        </div>
        
    </div>

<!-- OrtaAlan1 Son -->
</div>

            </div>

            <footer id="footer">
                <div class="container">
                    <div class="row">
                        <div id="ctl00_AltAlan_pnaltAlt">
	

<!-- ##Blok -->
<div class="col-md-4">

<div class="Blok" data-appear-animation="fadeIn" id="statik_288">
    <!-- Blok Başlık -->
    
    <div class="Area">
        <div style="background: #FFD266; border-radius: 100%; width: 40px; padding: 10px; height: 40px; text-align: center; display: inline-block;"><i class="fa fa-phone" style="font-size:16px;color:#1C1B19;"></i></div>

<p style="display: inline-block;">     <strong><span style="font-size:20px;line-height:40px;">+9(0212) 222 0 222</span></strong></p>

    </div>
</div>

</div>
<!-- ##Blok -->
<div class="col-md-4">

<div class="Blok" data-appear-animation="fadeIn" id="statik_254">
    <!-- Blok Başlık -->
    
    <div class="Area">
        <div style="background: #FFD266; border-radius: 100%; width: 40px; padding: 10px; height: 40px; text-align: center; display: inline-block;"><i class="fa fa-envelope" style="font-size:16px;color:#1C1B19;"></i></div>

<p style="display: inline-block;">     <strong><span style="font-size:20px;line-height:40px;">info@meryem.com</span></strong></p>

    </div>
</div>

</div>
<!-- ##Blok -->
<div class="col-md-4">

<div class="Blok" data-appear-animation="fadeIn" id="statik_251">
    <!-- Blok Başlık -->
    
    <div class="Area">
        
        <div class="social-theme10">
            <ul class="social-icons ">
                <li class="social-icons-facebook"><a href="https://www.facebook.com/facebook" target="_blank" title="Facebook"><i class="fab fa-facebook"></i></a></li><li class="social-icons-twitter"><a href="https://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li><li class="social-icons-instagram"><a href="https://www.instagram.com/novecoffeeco/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>
            </ul>
        </div>

        
    </div>
</div>

</div>
</div>
                    </div>
                </div>
                <div class="footer-copyright" style="display: block !important; visibility: visible !important;">
                    <div class="container" style="display: block !important; visibility: visible !important;">
                        <div class="row" style="display: block !important; visibility: visible !important;">
                            <div class="col-md-6" style="display: block !important; visibility: visible !important;">
                            MSB Coffee Shop Web Site - All Rights Reserved.
                            </div>
                            <div class="col-md-6 pull-right" style="display: block !important; visibility: visible !important;">
                                <div class="pull-right" style="display: block !important; visibility: visible !important;">
                                    <div class="bilgikurumsal GenislikSub"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </form>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

    <script src="https://hemencdn.com/interface/platinum/js/main.js"></script>

    <script>
        $('a[href="' + window.location.pathname + window.location.search + '"]').parents("li,ul").addClass("active");
    </script>

    <style>
        .UzunAlanIlanAra .container {
            padding-top: 10px;
            padding-bottom: 10px;
        }
    </style>

    
    


</body>
</html>