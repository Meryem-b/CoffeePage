<?php

// Create connection
$db = mysqli_connect("mysql.itu.edu.tr","db23983","7X7xcrRL5y","db23983"); // connecting 
// Check connection

if (!$db) {       //checking connection to DB	
    die("Connection failed: " . mysqli_connect_error());
}

?>